﻿using BankSolution.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace BankSolution.BLL
{
    public class TransactionServices
    {
        public List<Transaction> GetAllTransactions(int userId)
        {
            using (BankDBEntities context = new BankDBEntities())
            {
                return context.Transactions.Where(it => it.UserId == userId).Include(it => it.TransactionType).ToList();
            }
        }


        public List<Transaction> GetTransactionByDateRange(DateTime initialDate, DateTime endDate)
        {
            using (BankDBEntities context = new BankDBEntities())
            {
                var transactions = context.Transactions.Where(it => it.TransactionDate >= initialDate && it.TransactionDate <= endDate).Include(it => it.TransactionType).ToList();
                return transactions;
            }
        }

        public void CreateTrasaction(decimal amount, int transactionTypeId, int userId)
        {
            using (BankDBEntities context = new BankDBEntities())
            {
                Transaction t = new Transaction
                {
                    Amount = amount,
                    TransactionTypeId = transactionTypeId,
                    UserId = userId,
                    TransactionDate = DateTime.Now
                };

                context.Transactions.Add(t);
                context.SaveChanges();
            }
        }

        public void UpdateTransaction(int transactionId, decimal amount, int transactionTypeId)
        {
            using (BankDBEntities context = new BankDBEntities())
            {
                Transaction t = context.Transactions.FirstOrDefault(it => it.Id == transactionId);

                if (t == null)
                    throw new Exception("Transaction not found");

                t.Amount = amount;
                t.TransactionTypeId = transactionTypeId;

                context.Entry(t).State = System.Data.EntityState.Modified;
                context.SaveChanges();
            }
        }

        public void DeleteTransaction(int transactionId)
        {
            using (BankDBEntities context = new BankDBEntities())
            {
                Transaction t = context.Transactions.FirstOrDefault(it => it.Id == transactionId);

                if (t == null)
                    throw new Exception("Transaction not found");

                context.Entry(t).State = System.Data.EntityState.Deleted;
                context.SaveChanges();
            }
        }

        public void DeleteTransactions(List<int> transactionIds)
        {
            using (BankDBEntities context = new BankDBEntities())
            {

                foreach (int id in transactionIds)
                {
                    Transaction t = context.Transactions.FirstOrDefault(it => it.Id == id);
                    context.Entry(t).State = System.Data.EntityState.Deleted;
                }
                
                context.SaveChanges();
            }
        }

    }
}

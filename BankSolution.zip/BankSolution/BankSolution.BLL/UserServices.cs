﻿using BankSolution.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace BankSolution.BLL
{
    public class UserServices
    {
        public List<User> GetAllUsers()
        {
            using (BankDBEntities context = new BankDBEntities())
            {
                return context.Users.ToList();
            }
        }

        public User GetUser(string username, string password)
        {
            using (BankDBEntities context = new BankDBEntities())
            {
                return context.Users.FirstOrDefault(it => it.Username == username && it.Password == password);
            }
        }

        public void CreateUser(string username, string password, string firstName, string lastName, DateTime dob)
        {
            using (BankDBEntities context = new BankDBEntities())
            {
                if (context.Users.Any(it => it.Username == username))
                    return;

                User user = new User()
                {
                    Username = username,
                    Password = password,
                    FirstName = firstName,
                    LastName = lastName,
                    DOB = dob
                };

                context.Users.Add(user);

                context.SaveChanges();
            }
        }

        public bool ValidateUserNamePassword(string username, string password)
        {
            using (BankDBEntities context = new BankDBEntities())
            {
                return context.Users.Any(it => it.Username == username && it.Password == password);
            };
        }

        public void DeleteUser(int userId)
        {
            using (BankDBEntities context = new BankDBEntities())
            {
                User user = context.Users.FirstOrDefault(it => it.Id == userId);

                if (user == null)
                    throw new Exception("Couldn't find the user");

                context.Entry(user).State = System.Data.EntityState.Deleted;
                context.SaveChanges();
            };
        }

        public void UpdateUser(User user)
        {
            using (BankDBEntities context = new BankDBEntities())
            {  
                context.Users.Attach(user);
                context.Entry(user).State = System.Data.EntityState.Modified;
                context.SaveChanges();
            }
        }

        public List<User> GetUserByFilters(string username, string firstName, string lastName)
        {
            using (BankDBEntities context = new BankDBEntities())
            {
                var query = context.Users.AsQueryable();

                if (!string.IsNullOrEmpty(username))
                {
                    query = query.Where(it => it.Username.Contains(username));
                }

                if (!string.IsNullOrEmpty(firstName))
                {
                    query = query.Where(it => it.FirstName.Contains(firstName));
                }

                if (!string.IsNullOrEmpty(lastName))
                {
                    query = query.Where(it => it.LastName.Contains(lastName));
                }

                return query.ToList();
            }
        }
    }
}

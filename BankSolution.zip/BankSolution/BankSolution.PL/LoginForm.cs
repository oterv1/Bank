﻿using BankSolution.BLL;
using BankSolution.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankSolution.PL
{
    public partial class LoginForm : Form
    {
        public User ActiveUser { get; set; } 

        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            UserServices service = new UserServices();

            bool isValid = service.ValidateUserNamePassword(tbUsername.Text, tbPassword.Text);

            if (isValid)
            {
                ActiveUser = service.GetUser(tbUsername.Text, tbPassword.Text);
                Close();
            }                
            else
                MessageBox.Show("Invalid credentials");
        }
    }
}

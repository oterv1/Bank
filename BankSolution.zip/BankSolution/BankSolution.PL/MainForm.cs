﻿using BankSolution.BLL;
using BankSolution.DAL;
using BankSolution.PL.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankSolution.PL
{
    public partial class MainForm : Form
    {
        TransactionServices transactionServices;
        UserServices userServices;

        public decimal Balance { get; set; }

        public User ActiveUser { get; set; }

        public User SelectedUser { get; set; }
 
        public MainForm()
        {
            InitializeComponent();
            transactionServices = new TransactionServices();
            userServices = new UserServices();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            LoginForm loginForm = new LoginForm();
            loginForm.FormClosing += LoginForm_FormClosing;
            loginForm.ShowDialog();     
            

        }

        private void LoginForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            ActiveUser = ((LoginForm)sender).ActiveUser;
            UpdateTransactionGrid();
            gridUsers.DataSource = userServices.GetAllUsers();
        }

        private void itemTransaction_Click(object sender, EventArgs e)
        {
            panelTransactions.Visible = true;
            panelUsers.Visible = false;
        }

        private void itemUser_Click(object sender, EventArgs e)
        {
            panelTransactions.Visible = false;
            panelUsers.Visible = true;

            UserServices userService = new UserServices();

            List<User> users = userService.GetAllUsers();

            gridUsers.DataSource = users;            
        }

        private void btnDoTransaction_Click(object sender, EventArgs e)
        {
            if (nudAmount.Value <= 0)
                MessageBox.Show("Amount must be greater than 0");
            else if (rbWithdraw.Checked && Balance < nudAmount.Value)
                MessageBox.Show("Insuficient funds to dispense this amount");
            else
            {
                int transactionTypeId = rbDeposit.Checked ? 1 : 2;
                transactionServices.CreateTrasaction(nudAmount.Value, transactionTypeId, ActiveUser.Id);
                UpdateTransactionGrid();
            }            
        }

        private List<TransactionViewModel> Mapping(List<Transaction> transactions)
        {
            return transactions.Select(it => new TransactionViewModel
            {
                Id = it.Id,
                TransactionDate = it.TransactionDate,
                Amount = it.Amount,
                TransactionTypeId = it.TransactionTypeId,
                TransactionTypeName = it.TransactionType.Name,
                IsSelected = false
            }).ToList();
        }  

        private void UpdateTransactionGrid()
        {            
            var transactions = transactionServices.GetAllTransactions(ActiveUser.Id);
            List<TransactionViewModel> vmTransactions = Mapping(transactions);

            gridTransactions.DataSource = vmTransactions;
            Balance = (transactions.Where(it => it.TransactionTypeId == 1).Sum(it => it.Amount) - transactions.Where(it => it.TransactionTypeId == 2).Sum(it => it.Amount));
            lbBalanceValue.Text = Balance.ToString("0.00");
        }

        private void UpdateUserGrid()
        {
            var users = userServices.GetAllUsers();
            gridUsers.DataSource = users;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            DateTime from = dtpFrom.Value;
            DateTime to = dtpTo.Value;

            from = new DateTime(from.Year, from.Month, from.Day, 0, 0, 0);
            to = new DateTime(to.Year, to.Month, to.Day, 23, 59, 59);

            if (from > to)
                MessageBox.Show("Date from couldn't be greater than date to");
            else
            {
                List<Transaction> transactions = transactionServices.GetTransactionByDateRange(from, to);
                List<TransactionViewModel> vmTransactions = Mapping(transactions);

                gridTransactions.DataSource = vmTransactions;
            }            
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            List<TransactionViewModel> transactionsSelected = ((List<TransactionViewModel>)gridTransactions.DataSource).Where(it => it.IsSelected).ToList();

            if (transactionsSelected.Any())
            {
                transactionServices.DeleteTransactions(transactionsSelected.Select(it => it.Id).ToList());

                UpdateTransactionGrid();
            }            
        }

        private void btnAddUser_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tbUsername.Text))
            {
                MessageBox.Show("Username is required");
                return;
            }


            if (string.IsNullOrEmpty(tbPassword.Text))
            {
                MessageBox.Show("Password is required");
                return;
            }


            if (string.IsNullOrEmpty(tbFirstName.Text))
            {
                MessageBox.Show("First Name is required");
                return;
            }

            if (string.IsNullOrEmpty(tbLastName.Text))
            {
                MessageBox.Show("Last Name is required");
                return;
            }                

            userServices.CreateUser(tbUsername.Text, tbPassword.Text, tbFirstName.Text, tbLastName.Text, dtpDob.Value);

            UpdateUserGrid();
        }

        private void btnDeleteUser_Click(object sender, EventArgs e)
        {
            if (gridUsers.SelectedRows.Count > 0)
            {
                int id = (int)gridUsers.SelectedRows[0].Cells["Id"].Value;
                userServices.DeleteUser(id);
                UpdateUserGrid();
            }
            
        }

        private void gridUsers_SelectionChanged(object sender, EventArgs e)
        {
            if (gridUsers.SelectedRows.Count > 0)
            {
                User user = (User)gridUsers.CurrentRow.DataBoundItem;

                tbEditUsername.Text = user.Username;
                tbEditPassword.Text = user.Password;
                tbEditFirstName.Text = user.FirstName;
                tbEditLastName.Text = user.LastName;
                dtpEditDob.Value = user.DOB;

                SelectedUser = user;
            }
        }

        private void btnEditUser_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tbEditUsername.Text))
            {
                MessageBox.Show("Username is required");
                return;
            }


            if (string.IsNullOrEmpty(tbEditPassword.Text))
            {
                MessageBox.Show("Password is required");
                return;
            }


            if (string.IsNullOrEmpty(tbEditFirstName.Text))
            {
                MessageBox.Show("First Name is required");
                return;
            }

            if (string.IsNullOrEmpty(tbEditLastName.Text))
            {
                MessageBox.Show("Last Name is required");
                return;
            }

            SelectedUser.Username = tbEditUsername.Text;
            SelectedUser.Password = tbEditPassword.Text;
            SelectedUser.FirstName = tbEditFirstName.Text;
            SelectedUser.LastName = tbEditLastName.Text;
            SelectedUser.DOB = dtpEditDob.Value;

            userServices.UpdateUser(SelectedUser);

            UpdateUserGrid();
        }

        private void btnUserSearch_Click(object sender, EventArgs e)
        {
            var users = userServices.GetUserByFilters(tbFilterUsername.Text, tbFilterFirstName.Text, tbFilterLastName.Text);
            gridUsers.DataSource = users;
        }
    }
}

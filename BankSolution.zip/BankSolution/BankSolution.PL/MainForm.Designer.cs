﻿namespace BankSolution.PL
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itemUser = new System.Windows.Forms.ToolStripMenuItem();
            this.itemTransaction = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panelUsers = new System.Windows.Forms.Panel();
            this.gridUsers = new System.Windows.Forms.DataGridView();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passwordDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dOBDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.userBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panelUserDelete = new System.Windows.Forms.Panel();
            this.btnDeleteUser = new System.Windows.Forms.Button();
            this.panelUserFilters = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tbFilterLastName = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbFilterFirstName = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbFilterUsername = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnUserSearch = new System.Windows.Forms.Button();
            this.panelUserAddEdit = new System.Windows.Forms.Panel();
            this.gbEditUser = new System.Windows.Forms.GroupBox();
            this.dtpEditDob = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.tbEditLastName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbEditFirstName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbEditPassword = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbEditUsername = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnEditUser = new System.Windows.Forms.Button();
            this.gbUserAdd = new System.Windows.Forms.GroupBox();
            this.dtpDob = new System.Windows.Forms.DateTimePicker();
            this.lbDob = new System.Windows.Forms.Label();
            this.tbLastName = new System.Windows.Forms.TextBox();
            this.lbLastName = new System.Windows.Forms.Label();
            this.tbFirstName = new System.Windows.Forms.TextBox();
            this.lbFirstName = new System.Windows.Forms.Label();
            this.tbPassword = new System.Windows.Forms.TextBox();
            this.lbPassword = new System.Windows.Forms.Label();
            this.tbUsername = new System.Windows.Forms.TextBox();
            this.lbUsername = new System.Windows.Forms.Label();
            this.btnAddUser = new System.Windows.Forms.Button();
            this.panelTransactions = new System.Windows.Forms.Panel();
            this.gridTransactions = new System.Windows.Forms.DataGridView();
            this.IsSelected = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.TransactionDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panelTransactionDelete = new System.Windows.Forms.Panel();
            this.btnDelete = new System.Windows.Forms.Button();
            this.panelTransactionFilter = new System.Windows.Forms.Panel();
            this.lbBalanceValue = new System.Windows.Forms.Label();
            this.lbBalance = new System.Windows.Forms.Label();
            this.gbFilter = new System.Windows.Forms.GroupBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.lbTo = new System.Windows.Forms.Label();
            this.dtpTo = new System.Windows.Forms.DateTimePicker();
            this.lbFrom = new System.Windows.Forms.Label();
            this.dtpFrom = new System.Windows.Forms.DateTimePicker();
            this.panelTransactionAdd = new System.Windows.Forms.Panel();
            this.gbCreateTransaction = new System.Windows.Forms.GroupBox();
            this.nudAmount = new System.Windows.Forms.NumericUpDown();
            this.lbAmount = new System.Windows.Forms.Label();
            this.btnDoTransaction = new System.Windows.Forms.Button();
            this.rbDeposit = new System.Windows.Forms.RadioButton();
            this.rbWithdraw = new System.Windows.Forms.RadioButton();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.transactionTypeNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.transactionTypeIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.transactionViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.menuStrip1.SuspendLayout();
            this.panelUsers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridUsers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userBindingSource)).BeginInit();
            this.panelUserDelete.SuspendLayout();
            this.panelUserFilters.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panelUserAddEdit.SuspendLayout();
            this.gbEditUser.SuspendLayout();
            this.gbUserAdd.SuspendLayout();
            this.panelTransactions.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridTransactions)).BeginInit();
            this.panelTransactionDelete.SuspendLayout();
            this.panelTransactionFilter.SuspendLayout();
            this.gbFilter.SuspendLayout();
            this.panelTransactionAdd.SuspendLayout();
            this.gbCreateTransaction.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAmount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.transactionViewModelBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 1, 0, 1);
            this.menuStrip1.Size = new System.Drawing.Size(908, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itemUser,
            this.itemTransaction,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 22);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // itemUser
            // 
            this.itemUser.Name = "itemUser";
            this.itemUser.Size = new System.Drawing.Size(140, 22);
            this.itemUser.Text = "Users";
            this.itemUser.Click += new System.EventHandler(this.itemUser_Click);
            // 
            // itemTransaction
            // 
            this.itemTransaction.Name = "itemTransaction";
            this.itemTransaction.Size = new System.Drawing.Size(140, 22);
            this.itemTransaction.Text = "Transactions";
            this.itemTransaction.Click += new System.EventHandler(this.itemTransaction_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(140, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // panelUsers
            // 
            this.panelUsers.Controls.Add(this.gridUsers);
            this.panelUsers.Controls.Add(this.panelUserDelete);
            this.panelUsers.Controls.Add(this.panelUserFilters);
            this.panelUsers.Controls.Add(this.panelUserAddEdit);
            this.panelUsers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelUsers.Location = new System.Drawing.Point(0, 24);
            this.panelUsers.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panelUsers.Name = "panelUsers";
            this.panelUsers.Size = new System.Drawing.Size(908, 663);
            this.panelUsers.TabIndex = 1;
            this.panelUsers.Visible = false;
            // 
            // gridUsers
            // 
            this.gridUsers.AllowUserToAddRows = false;
            this.gridUsers.AllowUserToDeleteRows = false;
            this.gridUsers.AutoGenerateColumns = false;
            this.gridUsers.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridUsers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridUsers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id,
            this.usernameDataGridViewTextBoxColumn,
            this.passwordDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.dOBDataGridViewTextBoxColumn});
            this.gridUsers.DataSource = this.userBindingSource;
            this.gridUsers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridUsers.Location = new System.Drawing.Point(0, 162);
            this.gridUsers.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.gridUsers.MultiSelect = false;
            this.gridUsers.Name = "gridUsers";
            this.gridUsers.ReadOnly = true;
            this.gridUsers.RowTemplate.Height = 28;
            this.gridUsers.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gridUsers.Size = new System.Drawing.Size(695, 436);
            this.gridUsers.TabIndex = 0;
            this.gridUsers.SelectionChanged += new System.EventHandler(this.gridUsers_SelectionChanged);
            // 
            // Id
            // 
            this.Id.DataPropertyName = "Id";
            this.Id.HeaderText = "Id";
            this.Id.Name = "Id";
            this.Id.ReadOnly = true;
            this.Id.Visible = false;
            // 
            // usernameDataGridViewTextBoxColumn
            // 
            this.usernameDataGridViewTextBoxColumn.DataPropertyName = "Username";
            this.usernameDataGridViewTextBoxColumn.HeaderText = "Username";
            this.usernameDataGridViewTextBoxColumn.Name = "usernameDataGridViewTextBoxColumn";
            this.usernameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // passwordDataGridViewTextBoxColumn
            // 
            this.passwordDataGridViewTextBoxColumn.DataPropertyName = "Password";
            this.passwordDataGridViewTextBoxColumn.HeaderText = "Password";
            this.passwordDataGridViewTextBoxColumn.Name = "passwordDataGridViewTextBoxColumn";
            this.passwordDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            this.firstNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            this.lastNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dOBDataGridViewTextBoxColumn
            // 
            this.dOBDataGridViewTextBoxColumn.DataPropertyName = "DOB";
            this.dOBDataGridViewTextBoxColumn.HeaderText = "DOB";
            this.dOBDataGridViewTextBoxColumn.Name = "dOBDataGridViewTextBoxColumn";
            this.dOBDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // userBindingSource
            // 
            this.userBindingSource.DataSource = typeof(BankSolution.DAL.User);
            // 
            // panelUserDelete
            // 
            this.panelUserDelete.Controls.Add(this.btnDeleteUser);
            this.panelUserDelete.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelUserDelete.Location = new System.Drawing.Point(0, 598);
            this.panelUserDelete.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panelUserDelete.Name = "panelUserDelete";
            this.panelUserDelete.Size = new System.Drawing.Size(695, 65);
            this.panelUserDelete.TabIndex = 3;
            // 
            // btnDeleteUser
            // 
            this.btnDeleteUser.Location = new System.Drawing.Point(1161, 22);
            this.btnDeleteUser.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnDeleteUser.Name = "btnDeleteUser";
            this.btnDeleteUser.Size = new System.Drawing.Size(50, 23);
            this.btnDeleteUser.TabIndex = 0;
            this.btnDeleteUser.Text = "Delete";
            this.btnDeleteUser.UseVisualStyleBackColor = true;
            this.btnDeleteUser.Click += new System.EventHandler(this.btnDeleteUser_Click);
            // 
            // panelUserFilters
            // 
            this.panelUserFilters.Controls.Add(this.groupBox1);
            this.panelUserFilters.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelUserFilters.Location = new System.Drawing.Point(0, 0);
            this.panelUserFilters.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panelUserFilters.Name = "panelUserFilters";
            this.panelUserFilters.Size = new System.Drawing.Size(695, 162);
            this.panelUserFilters.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.tbFilterLastName);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.tbFilterFirstName);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.tbFilterUsername);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.btnUserSearch);
            this.groupBox1.Location = new System.Drawing.Point(8, 10);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(679, 144);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Filters";
            // 
            // tbFilterLastName
            // 
            this.tbFilterLastName.Location = new System.Drawing.Point(85, 67);
            this.tbFilterLastName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbFilterLastName.Name = "tbFilterLastName";
            this.tbFilterLastName.Size = new System.Drawing.Size(163, 20);
            this.tbFilterLastName.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(19, 69);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "Last Name";
            // 
            // tbFilterFirstName
            // 
            this.tbFilterFirstName.Location = new System.Drawing.Point(85, 44);
            this.tbFilterFirstName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbFilterFirstName.Name = "tbFilterFirstName";
            this.tbFilterFirstName.Size = new System.Drawing.Size(163, 20);
            this.tbFilterFirstName.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 45);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "First Name";
            // 
            // tbFilterUsername
            // 
            this.tbFilterUsername.Location = new System.Drawing.Point(85, 20);
            this.tbFilterUsername.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbFilterUsername.Name = "tbFilterUsername";
            this.tbFilterUsername.Size = new System.Drawing.Size(163, 20);
            this.tbFilterUsername.TabIndex = 10;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(19, 22);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "Username";
            // 
            // btnUserSearch
            // 
            this.btnUserSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUserSearch.Location = new System.Drawing.Point(625, 114);
            this.btnUserSearch.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnUserSearch.Name = "btnUserSearch";
            this.btnUserSearch.Size = new System.Drawing.Size(50, 23);
            this.btnUserSearch.TabIndex = 4;
            this.btnUserSearch.Text = "Search";
            this.btnUserSearch.UseVisualStyleBackColor = true;
            this.btnUserSearch.Click += new System.EventHandler(this.btnUserSearch_Click);
            // 
            // panelUserAddEdit
            // 
            this.panelUserAddEdit.Controls.Add(this.gbEditUser);
            this.panelUserAddEdit.Controls.Add(this.gbUserAdd);
            this.panelUserAddEdit.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelUserAddEdit.Location = new System.Drawing.Point(695, 0);
            this.panelUserAddEdit.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panelUserAddEdit.Name = "panelUserAddEdit";
            this.panelUserAddEdit.Size = new System.Drawing.Size(213, 663);
            this.panelUserAddEdit.TabIndex = 1;
            // 
            // gbEditUser
            // 
            this.gbEditUser.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbEditUser.Controls.Add(this.dtpEditDob);
            this.gbEditUser.Controls.Add(this.label1);
            this.gbEditUser.Controls.Add(this.tbEditLastName);
            this.gbEditUser.Controls.Add(this.label2);
            this.gbEditUser.Controls.Add(this.tbEditFirstName);
            this.gbEditUser.Controls.Add(this.label3);
            this.gbEditUser.Controls.Add(this.tbEditPassword);
            this.gbEditUser.Controls.Add(this.label4);
            this.gbEditUser.Controls.Add(this.tbEditUsername);
            this.gbEditUser.Controls.Add(this.label5);
            this.gbEditUser.Controls.Add(this.btnEditUser);
            this.gbEditUser.Location = new System.Drawing.Point(9, 330);
            this.gbEditUser.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.gbEditUser.Name = "gbEditUser";
            this.gbEditUser.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.gbEditUser.Size = new System.Drawing.Size(196, 310);
            this.gbEditUser.TabIndex = 9;
            this.gbEditUser.TabStop = false;
            this.gbEditUser.Text = "Edit User";
            // 
            // dtpEditDob
            // 
            this.dtpEditDob.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpEditDob.Location = new System.Drawing.Point(17, 246);
            this.dtpEditDob.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dtpEditDob.Name = "dtpEditDob";
            this.dtpEditDob.Size = new System.Drawing.Size(163, 20);
            this.dtpEditDob.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 231);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "DOB";
            // 
            // tbEditLastName
            // 
            this.tbEditLastName.Location = new System.Drawing.Point(17, 197);
            this.tbEditLastName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbEditLastName.Name = "tbEditLastName";
            this.tbEditLastName.Size = new System.Drawing.Size(163, 20);
            this.tbEditLastName.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 182);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Last Name";
            // 
            // tbEditFirstName
            // 
            this.tbEditFirstName.Location = new System.Drawing.Point(17, 146);
            this.tbEditFirstName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbEditFirstName.Name = "tbEditFirstName";
            this.tbEditFirstName.Size = new System.Drawing.Size(163, 20);
            this.tbEditFirstName.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 131);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "First Name";
            // 
            // tbEditPassword
            // 
            this.tbEditPassword.Location = new System.Drawing.Point(17, 96);
            this.tbEditPassword.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbEditPassword.Name = "tbEditPassword";
            this.tbEditPassword.Size = new System.Drawing.Size(163, 20);
            this.tbEditPassword.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 81);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Password";
            // 
            // tbEditUsername
            // 
            this.tbEditUsername.Location = new System.Drawing.Point(17, 45);
            this.tbEditUsername.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbEditUsername.Name = "tbEditUsername";
            this.tbEditUsername.Size = new System.Drawing.Size(163, 20);
            this.tbEditUsername.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 30);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Username";
            // 
            // btnEditUser
            // 
            this.btnEditUser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEditUser.Location = new System.Drawing.Point(129, 275);
            this.btnEditUser.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnEditUser.Name = "btnEditUser";
            this.btnEditUser.Size = new System.Drawing.Size(50, 23);
            this.btnEditUser.TabIndex = 5;
            this.btnEditUser.Text = "Edit";
            this.btnEditUser.UseVisualStyleBackColor = true;
            this.btnEditUser.Click += new System.EventHandler(this.btnEditUser_Click);
            // 
            // gbUserAdd
            // 
            this.gbUserAdd.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gbUserAdd.Controls.Add(this.dtpDob);
            this.gbUserAdd.Controls.Add(this.lbDob);
            this.gbUserAdd.Controls.Add(this.tbLastName);
            this.gbUserAdd.Controls.Add(this.lbLastName);
            this.gbUserAdd.Controls.Add(this.tbFirstName);
            this.gbUserAdd.Controls.Add(this.lbFirstName);
            this.gbUserAdd.Controls.Add(this.tbPassword);
            this.gbUserAdd.Controls.Add(this.lbPassword);
            this.gbUserAdd.Controls.Add(this.tbUsername);
            this.gbUserAdd.Controls.Add(this.lbUsername);
            this.gbUserAdd.Controls.Add(this.btnAddUser);
            this.gbUserAdd.Location = new System.Drawing.Point(9, 9);
            this.gbUserAdd.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.gbUserAdd.Name = "gbUserAdd";
            this.gbUserAdd.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.gbUserAdd.Size = new System.Drawing.Size(196, 309);
            this.gbUserAdd.TabIndex = 8;
            this.gbUserAdd.TabStop = false;
            this.gbUserAdd.Text = "Add User";
            // 
            // dtpDob
            // 
            this.dtpDob.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDob.Location = new System.Drawing.Point(17, 246);
            this.dtpDob.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dtpDob.Name = "dtpDob";
            this.dtpDob.Size = new System.Drawing.Size(163, 20);
            this.dtpDob.TabIndex = 14;
            // 
            // lbDob
            // 
            this.lbDob.AutoSize = true;
            this.lbDob.Location = new System.Drawing.Point(15, 231);
            this.lbDob.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbDob.Name = "lbDob";
            this.lbDob.Size = new System.Drawing.Size(30, 13);
            this.lbDob.TabIndex = 13;
            this.lbDob.Text = "DOB";
            // 
            // tbLastName
            // 
            this.tbLastName.Location = new System.Drawing.Point(17, 197);
            this.tbLastName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbLastName.Name = "tbLastName";
            this.tbLastName.Size = new System.Drawing.Size(163, 20);
            this.tbLastName.TabIndex = 12;
            // 
            // lbLastName
            // 
            this.lbLastName.AutoSize = true;
            this.lbLastName.Location = new System.Drawing.Point(16, 182);
            this.lbLastName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbLastName.Name = "lbLastName";
            this.lbLastName.Size = new System.Drawing.Size(58, 13);
            this.lbLastName.TabIndex = 11;
            this.lbLastName.Text = "Last Name";
            // 
            // tbFirstName
            // 
            this.tbFirstName.Location = new System.Drawing.Point(17, 146);
            this.tbFirstName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbFirstName.Name = "tbFirstName";
            this.tbFirstName.Size = new System.Drawing.Size(163, 20);
            this.tbFirstName.TabIndex = 10;
            // 
            // lbFirstName
            // 
            this.lbFirstName.AutoSize = true;
            this.lbFirstName.Location = new System.Drawing.Point(16, 131);
            this.lbFirstName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbFirstName.Name = "lbFirstName";
            this.lbFirstName.Size = new System.Drawing.Size(57, 13);
            this.lbFirstName.TabIndex = 9;
            this.lbFirstName.Text = "First Name";
            // 
            // tbPassword
            // 
            this.tbPassword.Location = new System.Drawing.Point(17, 96);
            this.tbPassword.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbPassword.Name = "tbPassword";
            this.tbPassword.Size = new System.Drawing.Size(163, 20);
            this.tbPassword.TabIndex = 8;
            // 
            // lbPassword
            // 
            this.lbPassword.AutoSize = true;
            this.lbPassword.Location = new System.Drawing.Point(15, 81);
            this.lbPassword.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbPassword.Name = "lbPassword";
            this.lbPassword.Size = new System.Drawing.Size(53, 13);
            this.lbPassword.TabIndex = 7;
            this.lbPassword.Text = "Password";
            // 
            // tbUsername
            // 
            this.tbUsername.Location = new System.Drawing.Point(17, 45);
            this.tbUsername.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbUsername.Name = "tbUsername";
            this.tbUsername.Size = new System.Drawing.Size(163, 20);
            this.tbUsername.TabIndex = 6;
            // 
            // lbUsername
            // 
            this.lbUsername.AutoSize = true;
            this.lbUsername.Location = new System.Drawing.Point(15, 30);
            this.lbUsername.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbUsername.Name = "lbUsername";
            this.lbUsername.Size = new System.Drawing.Size(55, 13);
            this.lbUsername.TabIndex = 0;
            this.lbUsername.Text = "Username";
            // 
            // btnAddUser
            // 
            this.btnAddUser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddUser.Location = new System.Drawing.Point(129, 274);
            this.btnAddUser.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnAddUser.Name = "btnAddUser";
            this.btnAddUser.Size = new System.Drawing.Size(50, 23);
            this.btnAddUser.TabIndex = 5;
            this.btnAddUser.Text = "Add";
            this.btnAddUser.UseVisualStyleBackColor = true;
            this.btnAddUser.Click += new System.EventHandler(this.btnAddUser_Click);
            // 
            // panelTransactions
            // 
            this.panelTransactions.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panelTransactions.Controls.Add(this.gridTransactions);
            this.panelTransactions.Controls.Add(this.panelTransactionDelete);
            this.panelTransactions.Controls.Add(this.panelTransactionFilter);
            this.panelTransactions.Controls.Add(this.panelTransactionAdd);
            this.panelTransactions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTransactions.Location = new System.Drawing.Point(0, 24);
            this.panelTransactions.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panelTransactions.Name = "panelTransactions";
            this.panelTransactions.Size = new System.Drawing.Size(908, 663);
            this.panelTransactions.TabIndex = 2;
            // 
            // gridTransactions
            // 
            this.gridTransactions.AllowUserToAddRows = false;
            this.gridTransactions.AllowUserToDeleteRows = false;
            this.gridTransactions.AutoGenerateColumns = false;
            this.gridTransactions.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridTransactions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridTransactions.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.IsSelected,
            this.TransactionDate,
            this.amountDataGridViewTextBoxColumn,
            this.transactionTypeNameDataGridViewTextBoxColumn,
            this.transactionTypeIdDataGridViewTextBoxColumn});
            this.gridTransactions.DataSource = this.transactionViewModelBindingSource;
            this.gridTransactions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridTransactions.Location = new System.Drawing.Point(0, 162);
            this.gridTransactions.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.gridTransactions.Name = "gridTransactions";
            this.gridTransactions.RowTemplate.Height = 28;
            this.gridTransactions.Size = new System.Drawing.Size(695, 436);
            this.gridTransactions.TabIndex = 6;
            // 
            // IsSelected
            // 
            this.IsSelected.DataPropertyName = "IsSelected";
            this.IsSelected.HeaderText = "";
            this.IsSelected.Name = "IsSelected";
            // 
            // TransactionDate
            // 
            this.TransactionDate.DataPropertyName = "TransactionDate";
            this.TransactionDate.HeaderText = "TransactionDate";
            this.TransactionDate.Name = "TransactionDate";
            this.TransactionDate.ReadOnly = true;
            // 
            // panelTransactionDelete
            // 
            this.panelTransactionDelete.BackColor = System.Drawing.SystemColors.Control;
            this.panelTransactionDelete.Controls.Add(this.btnDelete);
            this.panelTransactionDelete.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelTransactionDelete.Location = new System.Drawing.Point(0, 598);
            this.panelTransactionDelete.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panelTransactionDelete.Name = "panelTransactionDelete";
            this.panelTransactionDelete.Size = new System.Drawing.Size(695, 65);
            this.panelTransactionDelete.TabIndex = 9;
            // 
            // btnDelete
            // 
            this.btnDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDelete.Location = new System.Drawing.Point(629, 30);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(50, 23);
            this.btnDelete.TabIndex = 0;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // panelTransactionFilter
            // 
            this.panelTransactionFilter.BackColor = System.Drawing.SystemColors.Control;
            this.panelTransactionFilter.Controls.Add(this.lbBalanceValue);
            this.panelTransactionFilter.Controls.Add(this.lbBalance);
            this.panelTransactionFilter.Controls.Add(this.gbFilter);
            this.panelTransactionFilter.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTransactionFilter.Location = new System.Drawing.Point(0, 0);
            this.panelTransactionFilter.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panelTransactionFilter.Name = "panelTransactionFilter";
            this.panelTransactionFilter.Size = new System.Drawing.Size(695, 162);
            this.panelTransactionFilter.TabIndex = 8;
            // 
            // lbBalanceValue
            // 
            this.lbBalanceValue.AutoSize = true;
            this.lbBalanceValue.Location = new System.Drawing.Point(74, 127);
            this.lbBalanceValue.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbBalanceValue.Name = "lbBalanceValue";
            this.lbBalanceValue.Size = new System.Drawing.Size(13, 13);
            this.lbBalanceValue.TabIndex = 4;
            this.lbBalanceValue.Text = "0";
            // 
            // lbBalance
            // 
            this.lbBalance.AutoSize = true;
            this.lbBalance.Location = new System.Drawing.Point(8, 127);
            this.lbBalance.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbBalance.Name = "lbBalance";
            this.lbBalance.Size = new System.Drawing.Size(52, 13);
            this.lbBalance.TabIndex = 3;
            this.lbBalance.Text = "Balance: ";
            // 
            // gbFilter
            // 
            this.gbFilter.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbFilter.Controls.Add(this.btnSearch);
            this.gbFilter.Controls.Add(this.lbTo);
            this.gbFilter.Controls.Add(this.dtpTo);
            this.gbFilter.Controls.Add(this.lbFrom);
            this.gbFilter.Controls.Add(this.dtpFrom);
            this.gbFilter.Location = new System.Drawing.Point(8, 10);
            this.gbFilter.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.gbFilter.Name = "gbFilter";
            this.gbFilter.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.gbFilter.Size = new System.Drawing.Size(683, 76);
            this.gbFilter.TabIndex = 2;
            this.gbFilter.TabStop = false;
            this.gbFilter.Text = "Filters";
            // 
            // btnSearch
            // 
            this.btnSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSearch.Location = new System.Drawing.Point(629, 46);
            this.btnSearch.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(50, 23);
            this.btnSearch.TabIndex = 4;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // lbTo
            // 
            this.lbTo.AutoSize = true;
            this.lbTo.Location = new System.Drawing.Point(16, 48);
            this.lbTo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbTo.Name = "lbTo";
            this.lbTo.Size = new System.Drawing.Size(20, 13);
            this.lbTo.TabIndex = 3;
            this.lbTo.Text = "To";
            // 
            // dtpTo
            // 
            this.dtpTo.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpTo.Location = new System.Drawing.Point(51, 46);
            this.dtpTo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dtpTo.Name = "dtpTo";
            this.dtpTo.Size = new System.Drawing.Size(135, 20);
            this.dtpTo.TabIndex = 2;
            // 
            // lbFrom
            // 
            this.lbFrom.AutoSize = true;
            this.lbFrom.Location = new System.Drawing.Point(16, 20);
            this.lbFrom.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbFrom.Name = "lbFrom";
            this.lbFrom.Size = new System.Drawing.Size(30, 13);
            this.lbFrom.TabIndex = 1;
            this.lbFrom.Text = "From";
            // 
            // dtpFrom
            // 
            this.dtpFrom.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFrom.Location = new System.Drawing.Point(51, 18);
            this.dtpFrom.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dtpFrom.Name = "dtpFrom";
            this.dtpFrom.Size = new System.Drawing.Size(135, 20);
            this.dtpFrom.TabIndex = 0;
            // 
            // panelTransactionAdd
            // 
            this.panelTransactionAdd.BackColor = System.Drawing.SystemColors.Control;
            this.panelTransactionAdd.Controls.Add(this.gbCreateTransaction);
            this.panelTransactionAdd.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelTransactionAdd.Location = new System.Drawing.Point(695, 0);
            this.panelTransactionAdd.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panelTransactionAdd.Name = "panelTransactionAdd";
            this.panelTransactionAdd.Size = new System.Drawing.Size(213, 663);
            this.panelTransactionAdd.TabIndex = 7;
            // 
            // gbCreateTransaction
            // 
            this.gbCreateTransaction.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbCreateTransaction.Controls.Add(this.nudAmount);
            this.gbCreateTransaction.Controls.Add(this.lbAmount);
            this.gbCreateTransaction.Controls.Add(this.btnDoTransaction);
            this.gbCreateTransaction.Controls.Add(this.rbDeposit);
            this.gbCreateTransaction.Controls.Add(this.rbWithdraw);
            this.gbCreateTransaction.Location = new System.Drawing.Point(9, 10);
            this.gbCreateTransaction.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.gbCreateTransaction.Name = "gbCreateTransaction";
            this.gbCreateTransaction.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.gbCreateTransaction.Size = new System.Drawing.Size(196, 646);
            this.gbCreateTransaction.TabIndex = 7;
            this.gbCreateTransaction.TabStop = false;
            this.gbCreateTransaction.Text = "Create Transaction";
            // 
            // nudAmount
            // 
            this.nudAmount.DecimalPlaces = 2;
            this.nudAmount.Location = new System.Drawing.Point(62, 26);
            this.nudAmount.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.nudAmount.Name = "nudAmount";
            this.nudAmount.Size = new System.Drawing.Size(117, 20);
            this.nudAmount.TabIndex = 6;
            // 
            // lbAmount
            // 
            this.lbAmount.AutoSize = true;
            this.lbAmount.Location = new System.Drawing.Point(15, 30);
            this.lbAmount.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbAmount.Name = "lbAmount";
            this.lbAmount.Size = new System.Drawing.Size(43, 13);
            this.lbAmount.TabIndex = 0;
            this.lbAmount.Text = "Amount";
            // 
            // btnDoTransaction
            // 
            this.btnDoTransaction.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDoTransaction.Location = new System.Drawing.Point(142, 618);
            this.btnDoTransaction.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnDoTransaction.Name = "btnDoTransaction";
            this.btnDoTransaction.Size = new System.Drawing.Size(50, 23);
            this.btnDoTransaction.TabIndex = 5;
            this.btnDoTransaction.Text = "Do";
            this.btnDoTransaction.UseVisualStyleBackColor = true;
            this.btnDoTransaction.Click += new System.EventHandler(this.btnDoTransaction_Click);
            // 
            // rbDeposit
            // 
            this.rbDeposit.AutoSize = true;
            this.rbDeposit.Checked = true;
            this.rbDeposit.Location = new System.Drawing.Point(17, 58);
            this.rbDeposit.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rbDeposit.Name = "rbDeposit";
            this.rbDeposit.Size = new System.Drawing.Size(61, 17);
            this.rbDeposit.TabIndex = 2;
            this.rbDeposit.TabStop = true;
            this.rbDeposit.Text = "Deposit";
            this.rbDeposit.UseVisualStyleBackColor = true;
            // 
            // rbWithdraw
            // 
            this.rbWithdraw.AutoSize = true;
            this.rbWithdraw.Location = new System.Drawing.Point(112, 58);
            this.rbWithdraw.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rbWithdraw.Name = "rbWithdraw";
            this.rbWithdraw.Size = new System.Drawing.Size(70, 17);
            this.rbWithdraw.TabIndex = 3;
            this.rbWithdraw.Text = "Withdraw";
            this.rbWithdraw.UseVisualStyleBackColor = true;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            this.idDataGridViewTextBoxColumn.Visible = false;
            // 
            // amountDataGridViewTextBoxColumn
            // 
            this.amountDataGridViewTextBoxColumn.DataPropertyName = "Amount";
            this.amountDataGridViewTextBoxColumn.HeaderText = "Amount";
            this.amountDataGridViewTextBoxColumn.Name = "amountDataGridViewTextBoxColumn";
            this.amountDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // transactionTypeNameDataGridViewTextBoxColumn
            // 
            this.transactionTypeNameDataGridViewTextBoxColumn.DataPropertyName = "TransactionTypeName";
            this.transactionTypeNameDataGridViewTextBoxColumn.HeaderText = "Transaction Type";
            this.transactionTypeNameDataGridViewTextBoxColumn.Name = "transactionTypeNameDataGridViewTextBoxColumn";
            this.transactionTypeNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // transactionTypeIdDataGridViewTextBoxColumn
            // 
            this.transactionTypeIdDataGridViewTextBoxColumn.DataPropertyName = "TransactionTypeId";
            this.transactionTypeIdDataGridViewTextBoxColumn.HeaderText = "TransactionTypeId";
            this.transactionTypeIdDataGridViewTextBoxColumn.Name = "transactionTypeIdDataGridViewTextBoxColumn";
            this.transactionTypeIdDataGridViewTextBoxColumn.ReadOnly = true;
            this.transactionTypeIdDataGridViewTextBoxColumn.Visible = false;
            // 
            // transactionViewModelBindingSource
            // 
            this.transactionViewModelBindingSource.DataSource = typeof(BankSolution.PL.Model.TransactionViewModel);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(908, 687);
            this.Controls.Add(this.panelUsers);
            this.Controls.Add(this.panelTransactions);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "MainForm";
            this.Text = "Bank App";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panelUsers.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridUsers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userBindingSource)).EndInit();
            this.panelUserDelete.ResumeLayout(false);
            this.panelUserFilters.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panelUserAddEdit.ResumeLayout(false);
            this.gbEditUser.ResumeLayout(false);
            this.gbEditUser.PerformLayout();
            this.gbUserAdd.ResumeLayout(false);
            this.gbUserAdd.PerformLayout();
            this.panelTransactions.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridTransactions)).EndInit();
            this.panelTransactionDelete.ResumeLayout(false);
            this.panelTransactionFilter.ResumeLayout(false);
            this.panelTransactionFilter.PerformLayout();
            this.gbFilter.ResumeLayout(false);
            this.gbFilter.PerformLayout();
            this.panelTransactionAdd.ResumeLayout(false);
            this.gbCreateTransaction.ResumeLayout(false);
            this.gbCreateTransaction.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAmount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.transactionViewModelBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itemTransaction;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itemUser;
        private System.Windows.Forms.Panel panelUsers;
        private System.Windows.Forms.DataGridView gridUsers;
        private System.Windows.Forms.Panel panelTransactions;
        private System.Windows.Forms.Panel panelTransactionFilter;
        private System.Windows.Forms.GroupBox gbFilter;
        private System.Windows.Forms.DateTimePicker dtpFrom;
        private System.Windows.Forms.DataGridView gridTransactions;
        private System.Windows.Forms.Panel panelTransactionAdd;
        private System.Windows.Forms.RadioButton rbWithdraw;
        private System.Windows.Forms.RadioButton rbDeposit;
        private System.Windows.Forms.Label lbAmount;
        private System.Windows.Forms.Button btnDoTransaction;
        private System.Windows.Forms.NumericUpDown nudAmount;
        private System.Windows.Forms.Label lbBalanceValue;
        private System.Windows.Forms.Label lbBalance;
        private System.Windows.Forms.DataGridViewTextBoxColumn transactionTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.GroupBox gbCreateTransaction;
        private System.Windows.Forms.BindingSource transactionViewModelBindingSource;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label lbTo;
        private System.Windows.Forms.DateTimePicker dtpTo;
        private System.Windows.Forms.Label lbFrom;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn IsSelected;
        private System.Windows.Forms.DataGridViewTextBoxColumn TransactionDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn transactionTypeNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn transactionTypeIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.Panel panelTransactionDelete;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.BindingSource userBindingSource;
        private System.Windows.Forms.Panel panelUserDelete;
        private System.Windows.Forms.Panel panelUserFilters;
        private System.Windows.Forms.Panel panelUserAddEdit;
        private System.Windows.Forms.Button btnDeleteUser;
        private System.Windows.Forms.GroupBox gbEditUser;
        private System.Windows.Forms.DateTimePicker dtpEditDob;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbEditLastName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbEditFirstName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbEditPassword;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbEditUsername;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnEditUser;
        private System.Windows.Forms.GroupBox gbUserAdd;
        private System.Windows.Forms.DateTimePicker dtpDob;
        private System.Windows.Forms.Label lbDob;
        private System.Windows.Forms.TextBox tbLastName;
        private System.Windows.Forms.Label lbLastName;
        private System.Windows.Forms.TextBox tbFirstName;
        private System.Windows.Forms.Label lbFirstName;
        private System.Windows.Forms.TextBox tbPassword;
        private System.Windows.Forms.Label lbPassword;
        private System.Windows.Forms.TextBox tbUsername;
        private System.Windows.Forms.Label lbUsername;
        private System.Windows.Forms.Button btnAddUser;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnUserSearch;
        private System.Windows.Forms.TextBox tbFilterLastName;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbFilterFirstName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbFilterUsername;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn usernameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn passwordDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dOBDataGridViewTextBoxColumn;
    }
}

